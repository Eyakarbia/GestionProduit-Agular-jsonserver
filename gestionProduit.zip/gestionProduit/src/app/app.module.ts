import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ListeproduitComponent } from './listeproduit/listeproduit.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DetailproduitComponent } from './detailproduit/detailproduit.component';
import {HttpClient, HttpClientModule}   from '@angular/common/http';
import { AjoutProduit1Component } from './ajout-produit1/ajout-produit1.component';
import { HomeComponent } from './home/home.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { LoginComponent } from './login/login.component';
import { DetailsComponent } from './details/details.component';
import { CardComponent } from './card/card.component';
import { UpdateComponent } from './update/update.component';


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    ListeproduitComponent,
    DetailproduitComponent,
    AjoutProduit1Component,
    HomeComponent,
    SignUpComponent,
    LoginComponent,
    DetailsComponent,
    CardComponent,
    UpdateComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
   HttpClientModule,
   ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
