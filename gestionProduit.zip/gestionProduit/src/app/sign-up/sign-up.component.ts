import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ProduitService } from '../services/produit.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
 // @ts-ignore
 form :FormGroup;
  constructor(private service:ProduitService) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      email: new FormControl('', Validators.minLength(2)),
      password: new FormControl(''),
      PhoneNumber: new FormControl(''),
    });
  }
signup(){
  this.service.signup(this.form.value).subscribe(res=>{
    Swal.fire({
      title: 'SIGN UP SUCCESSFULLY',
      showClass: {
        popup: 'animate__animated animate__fadeInDown'
      },
      hideClass: {
        popup: 'animate__animated animate__fadeOutUp'
      }
    })
    this.form.reset();
   
  
   },err =>{
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Something went wrong!',
      footer: '<a href="">Why do I have this issue?</a>'
    })
   }
   )
}
}
