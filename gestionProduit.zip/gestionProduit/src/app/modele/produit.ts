export interface Produit {
    id : number
    nom : string 
    quantite : number 
    prix :number
    image:string
}
