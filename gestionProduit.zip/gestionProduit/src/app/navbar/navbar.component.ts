import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProduitService } from '../services/produit.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  isLoggin:boolean=false
  constructor(private router:Router , public produitService:ProduitService ) { }

  ngOnInit(): void {
  }
  logout(){
    localStorage.removeItem("UserToken")
    this.produitService.isLoggin=false

    this.router.navigate(['/login'])
  }
}
