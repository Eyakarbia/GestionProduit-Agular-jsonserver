import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient} from '@angular/common/http';
import { Produit } from '../modele/produit';
@Injectable({
  providedIn: 'root'
})
export class ProduitService {
host="http://localhost:3000/produits/"
url="http://localhost:3000/signup"
isLoggin:boolean=false
  constructor(private http:HttpClient) 
  {  if(localStorage.getItem("UserToken")){
    this.isLoggin=true
  }else{
    this.isLoggin=false
  }}
  public getProduct():Observable <Produit[]>
  {
  return this.http.get<Produit[]>(this.host );
}

getProductByid(id:number):Observable <Produit>{
return this.http.get<Produit>(this.host +id);

}
remove(id:number):Observable<void>{
return this.http.delete<void>(this.host +id);
}
Addproduct(p:any):Observable<void>{
  return this.http.post<void>(this.host,p)

}
signup(d:any):Observable<void>{
  return this.http.post<void>(this.url,d);

}
details(id:number):Observable <Produit>{
  return this.http.get<Produit>(this.host +id);
}
Update(p:any,id:number):Observable<void>{
  return this.http.put<void>(this.host+id,p);

}

}
