import { Component, OnInit } from '@angular/core';
import { ProduitService } from '../services/produit.service';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {

  products: any = [];
  constructor( private service:ProduitService) { }

  ngOnInit(): void {
    this.getProducts();
  }
  getProducts(){
    this.service.getProduct().subscribe((data)=>{
      this.products=data;
      
    })
  }
}