import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Produit } from '../modele/produit';
import { ProduitService } from '../services/produit.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  id!:number;
  role!:string
  prod!:Produit;
  formproduct : any
  constructor(private ar: ActivatedRoute , private service : ProduitService, private router: Router , private formbuilder : FormBuilder) {
    
   }

  ngOnInit(): void {
    this.ar.paramMap.subscribe((param:any ) =>{
      this.role=param.get('role');
      this.id=param.get('id');
    });

    this.service.getProductByid(this.id).subscribe((data)=>{
      this.prod=data;
    });
 
  }

  onSubmit(){
    this.service.Update( this.prod,this.prod.id).subscribe(date =>{
      alert('modofié avec succé')
    });
    this.router.navigate(['/listeproduit', this.role]).then(()=>{
      window.location.reload();
    })
  }

}

