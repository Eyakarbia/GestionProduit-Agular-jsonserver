import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AjoutProduit1Component } from './ajout-produit1/ajout-produit1.component';
import { CardComponent } from './card/card.component';
import { DetailproduitComponent } from './detailproduit/detailproduit.component';
import { DetailsComponent } from './details/details.component';
import { HomeComponent } from './home/home.component';
import { ListeproduitComponent } from './listeproduit/listeproduit.component';
import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { UpdateComponent } from './update/update.component';

const routes: Routes = [{path:"listeproduit",component:ListeproduitComponent},
{path:"produit1",component:AjoutProduit1Component},

{path:"",redirectTo:"home",pathMatch:'full'},
{path:"product/:id",component:DetailproduitComponent},
{path:"home",component:HomeComponent},
{path:"sign-up",component:SignUpComponent},
{path:"login",component:LoginComponent},
{path:"details",component:DetailsComponent},
{path:"card",component:CardComponent},
{path:"update/:id",component:UpdateComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
